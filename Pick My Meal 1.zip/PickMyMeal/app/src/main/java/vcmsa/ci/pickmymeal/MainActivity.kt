package vcmsa.ci.pickmymeal

import android.media.TimedText
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.TextView
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val timeInput = findViewById<EditText>(R.id.edtTime)
        val pickButton = findViewById<Button>(R.id.btnPick)
        val clearButton = findViewById<Button>(R.id.btnClr)
        val mealSuggestion = findViewById<TextView>(R.id.txtOutput)

        pickButton.setOnClickListener {
            val timeText = timeInput.text.toString()
            val time = timeText.toIntOrNull()
            val Suggestion = when (time) {
                in 5..9-> " Breakfast: Egg tuna roll"
                in 10..11-> " Mid-Morning Snack: Yougurt and Fruits "
                in 12..14-> "Lunch: Grilled Chicken with Rice"
                in 15..16-> "Mid-Afternoon Snack: Nuts and Smoothie"
                in 17..21-> "Dinner: Pasta with Vegetables "
                in 21..23,in 0..4->"Late night snack: Hot chocolate with cookies"
                else -> "Invalid time entered"


            }
            mealSuggestion.text= Suggestion
        }
        clearButton.setOnClickListener {
           timeInput.text.clear()
            mealSuggestion.text = ""

        }










        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}